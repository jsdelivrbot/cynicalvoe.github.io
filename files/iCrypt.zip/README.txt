iCrypt by xFyreWolfX. Copyright 2016, All Rights Reserved.
—

iCrypt is a simple GUI-based single file encryption/decryption program. iCrypt has two built-in algorithms: Blowfish and DES, each with a random key generator. iCrypt uses Java’s Cypher function and stores encrypted files in a .enc file.

The developer of iCrypt (me) is not responsible for misuse of the program, nor lost files due to error. Use at your own risk.

Happy Encrypting!
~xFyreWolfx